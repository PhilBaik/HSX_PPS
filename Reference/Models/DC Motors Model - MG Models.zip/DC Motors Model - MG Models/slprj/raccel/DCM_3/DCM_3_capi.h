#include "__cf_DCM_3.h"
#ifndef RTW_HEADER_DCM_3_capi_h
#define RTW_HEADER_DCM_3_capi_h
#include "DCM_3.h"
extern void DCM_3_InitializeDataMapInfo ( void ) ;
#endif
