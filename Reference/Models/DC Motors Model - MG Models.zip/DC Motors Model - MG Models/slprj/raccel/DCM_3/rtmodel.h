#include "__cf_DCM_3.h"
#ifndef RTW_HEADER_rtmodel_h_
#define RTW_HEADER_rtmodel_h_
#include "DCM_3.h"
#define GRTINTERFACE 1
#endif
